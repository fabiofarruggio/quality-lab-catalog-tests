# Versioned Playwright suite foundation

TASK-019 / REQ-FW-001: a real `@aqp/qa-framework-template` package and bounded TeamManifest generator. The shared fixtures are packaged once at **0.1.0** and installed by consumers, not copied into each squad. This is not the framework-engineer product agent or a generated-code sandbox.

## Reproduce locally

Use Node **24.21.0** and npm **11.19.0**. From this repository:

```powershell
npm ci --ignore-scripts
npm run typecheck
npm test
npm run pack:local
node dist/cli.js --manifest artifacts/catalog-team-manifest.json --output-root .. --library-tarball artifacts/aqp-qa-framework-template-0.1.0.tgz
```

The final command refuses an existing generated consumer. Choose a new authorized output parent for experiments; do not delete an existing suite to rerun it. An existing destination may contain only bootstrap `.git`, `.codegraph`, `.gitignore`, and `AGENTS.md`. All generated files are created exclusively. An interrupted write leaves visible partial output and never triggers automatic cleanup.

## Boundaries

- `schemas/` contains byte-preserved copies of the baseline's TeamManifest and common schemas. Ajv2020 validates them offline; no schema retrieval is configured.
- Both `catalog` and `orders` use the same generator. It enforces template compatibility, canonical HTTP(S) origins and safe repository/write-path syntax. It preserves all input provenance rather than inventing SHAs or remote IDs.
- `artifacts/catalog-team-manifest.json` uses a real platform bootstrap commit and hashes of its current policy/agent config. That commit alone is not a claim that uncommitted implementation files were already contained in it.
- QLAB is a planned logical Jira key. Repository names are local logical names. No remote repository, Jira project or knowledge page is claimed to exist.
- `LabApi` shares real Playwright HTTP contexts, synthetic login and cleanup. It rejects cross-origin path requests and automatic redirects. This convenience restriction is **not** a sandbox: arbitrary test code can still access the host unless a separate runner isolates it.
- Generated readiness tests and catalog definitions are initially unverified. Consumer business tests and real runtime evidence are required separately.
- The local tarball is trusted maintainer build input; SHA-256 records its identity, not publisher authenticity. No registry publication is authorized.

## Version sources

Registry versions were read on 2026-09-17 UTC and fixed in the lock: Playwright 1.63.0, Ajv 8.20.0, ajv-formats 3.0.1, TypeScript 6.0.3 and Vitest 5.0.1. Implementation follows [Playwright fixtures](https://playwright.dev/docs/test-fixtures), [API testing](https://playwright.dev/docs/api-testing), and [Ajv JSON Schema 2020-12](https://ajv.js.org/json-schema.html).

## Rollback and next verification

This work unit includes the library, generator, tests, schemas and local package artifacts. Removing it does not alter the immutable PRD or any remote state. Regenerate consumers only through reviewed changes; do not centrally overwrite them. Real Docker/PostgreSQL runner isolation, CI execution and product-agent behavior are outside these local checks.
